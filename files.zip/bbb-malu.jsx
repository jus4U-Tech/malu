import { useState, useRef, useEffect } from "react";

// ── Cores ──────────────────────────────────────────────────────────────────
const PINK    = "#e91e8c";
const GOLD    = "#f5c842";
const DARK    = "#0d0d1a";
const CARD_BG = "#13132a";

const SK_PART    = "bbb-malu-participantes";
const SK_CONFIG  = "bbb-malu-config";
const SK_ADMIN   = "bbb-malu-admin";

const CONFIG_ZERO = {
  prdFotos: "",
};

const ADMIN_ZERO = {
  env: "development",
  // PostgreSQL / Docker (dev)
  pgHost: "localhost",
  pgPort: "5432",
  pgDb: "bbb_malu",
  pgUser: "postgres",
  pgPassword: "",
  // Supabase (prod)
  supabaseUrl: "",
  supabaseAnonKey: "",
  supabaseServiceKey: "",
  // Vercel
  vercelToken: "",
  vercelProjectId: "",
  vercelOrgId: "",
  // GitHub
  githubRepo: "",
  githubToken: "",
  // App
  appName: "BBB da Malu",
  appUrl: "",
};

// ── Helpers de estilo ──────────────────────────────────────────────────────
const inputStyle = {
  width: "100%", background: "#1a1a35", border: "1px solid #444",
  borderRadius: 8, padding: "9px 12px", color: "#fff",
  fontSize: 14, boxSizing: "border-box", outline: "none", marginBottom: 4,
};
const labelStyle = {
  display: "block", color: "rgba(255,255,255,0.6)",
  fontSize: 12, marginBottom: 4, marginTop: 14,
};
function btnStyle(bg, color = "#fff", extra = {}) {
  return {
    background: bg, color, border: "none", borderRadius: 8,
    padding: "9px 18px", cursor: "pointer", fontWeight: "bold",
    fontSize: 13, transition: "all .15s", ...extra,
  };
}

// ── Utilitários ────────────────────────────────────────────────────────────
function capitalize(str) {
  if (!str) return "";
  return str.toLowerCase().split(" ")
    .map(w => w.length > 2 ? w.charAt(0).toUpperCase() + w.slice(1) : w)
    .join(" ").replace(/^\w/, c => c.toUpperCase());
}

function compressImage(file, maxW = 900) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const scale = Math.min(1, maxW / img.width);
        const canvas = document.createElement("canvas");
        canvas.width  = Math.round(img.width  * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.75));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

function parseDate(str) {
  if (!str || str.length < 5) return null;
  const [m, y] = str.split("/");
  const month = parseInt(m, 10), year = parseInt("20" + y, 10);
  if (isNaN(month) || isNaN(year)) return null;
  return new Date(year, month - 1);
}

// ── Status calculado pelo palpite ─────────────────────────────────────────
// "Eliminado"  → palpite em mês/ano anterior ao atual
// "No Paredão" → palpite no mês/ano atual
// "Na Casa"    → palpite em mês/ano futuro, ou sem palpite
function calcStatus(palpite) {
  if (!palpite || palpite.trim() === "") return "Sem Palpite";
  
  const pDate = parseDate(palpite);
  if (!pDate) return "Sem Palpite";
  const hoje = new Date();
  const anoHoje = hoje.getFullYear(), mesHoje = hoje.getMonth();
  const anoPalp = pDate.getFullYear(), mesPalp = pDate.getMonth();
  if (anoPalp < anoHoje || (anoPalp === anoHoje && mesPalp < mesHoje)) return "Eliminado";
  if (anoPalp === anoHoje && mesPalp === mesHoje) return "No Paredão";
  return "Na Casa";
}

const STATUS_CONFIG = {
  "Na Casa":     { color: "#27ae60", bg: "#1a4a2e", icon: "🏠", pdf: [39, 174, 96]  },
  "No Paredão":  { color: "#e67e22", bg: "#4a2a0a", icon: "🔥", pdf: [230, 126, 34] },
  "Eliminado":   { color: "#c0392b", bg: "#4a1010", icon: "❌", pdf: [192, 57, 43]  },
  "Sem Palpite": { color: "#7f8c8d", bg: "#1a1f22", icon: "❓", pdf: [127, 140, 141] },
};

function maskPalpite(raw) {
  const digits = raw.replace(/\D/g, "").slice(0, 4);
  if (digits.length <= 2) return digits;
  return digits.slice(0, 2) + "/" + digits.slice(2);
}

// ── jsPDF loader ──────────────────────────────────────────────────────────
let jsPDFLoaded = false;
async function loadJsPDF() {
  if (jsPDFLoaded && window.jspdf) return window.jspdf.jsPDF;
  return new Promise((resolve, reject) => {
    if (document.querySelector("script[data-jspdf]")) {
      const wait = setInterval(() => { if (window.jspdf) { clearInterval(wait); resolve(window.jspdf.jsPDF); } }, 50);
      return;
    }
    const s = document.createElement("script");
    s.setAttribute("data-jspdf", "1");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
    s.onload  = () => { jsPDFLoaded = true; resolve(window.jspdf.jsPDF); };
    s.onerror = () => reject(new Error("Falha ao carregar jsPDF"));
    document.head.appendChild(s);
  });
}

// ── Storage helpers ───────────────────────────────────────────────────────
async function storageSave(key, value) {
  try { await window.storage.set(key, JSON.stringify(value)); } catch {}
}
async function storageLoad(key, fallback) {
  try {
    const r = await window.storage.get(key);
    if (r && r.value) return JSON.parse(r.value);
  } catch {}
  return fallback;
}

// ── API Anthropic ─────────────────────────────────────────────────────────
async function apiCall(system, userContent, maxTokens = 1000) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: maxTokens,
      system,
      messages: [{ role: "user", content: userContent }],
    }),
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  return data.content.map(b => b.text || "").join("");
}

async function interpretarLista(texto) {
  const raw = await apiCall(
    `Você é um assistente que extrai dados de listas de participantes de bolões.
Analise o texto e extraia: nome e palpite de data no formato MM/AA.
Palpites podem ser: "março de 2025" → 03/25, "04/2025" → 04/25, etc.
Se não houver palpite, deixe como "".
Responda SOMENTE com JSON válido, sem markdown.
Formato: {"participantes": [{"nome": "Nome Completo", "palpite": "MM/AA"}]}`,
    texto
  );
  return JSON.parse(raw.replace(/```json|```/g, "").trim());
}

// Processa uma foto com base no PRD de fotos definido nas configurações
async function processarFotoComIA(base64DataUrl, prdFotos) {
  const base64 = base64DataUrl.split(",")[1];
  const instrucao = prdFotos.trim() || "Melhore levemente a foto: ajuste brilho, contraste e nitidez de forma sutil. Retorne APENAS o base64 JPEG da imagem resultante, sem nenhum texto adicional, sem markdown, sem prefixo data:image.";

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      system: `Você é um processador de imagens. O usuário fornecerá uma imagem e instruções de tratamento.
Siga as instruções e retorne SOMENTE o base64 puro da imagem JPEG resultante, sem prefixo, sem markdown, sem texto.`,
      messages: [{
        role: "user",
        content: [
          { type: "image", source: { type: "base64", media_type: "image/jpeg", data: base64 } },
          { type: "text", text: instrucao + "\n\nRetorne APENAS o base64 JPEG puro, sem nenhum texto." }
        ]
      }],
    }),
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  const b64 = data.content.map(b => b.text || "").join("").replace(/```|data:image[^;]*;base64,/g, "").trim();
  return `data:image/jpeg;base64,${b64}`;
}

// ── Constante form ────────────────────────────────────────────────────────
// status e calculado pelo palpite via calcStatus()
const FORM_ZERO = { nome: "", palpite: "", fotos: [] };

// ═════════════════════════════════════════════════════════════════════════════
// APP PRINCIPAL
// ═════════════════════════════════════════════════════════════════════════════
export default function App() {
  const [participantes,  setParticipantes]  = useState([]);
  const [config,         setConfig]         = useState(CONFIG_ZERO);
  const [storageReady,   setStorageReady]   = useState(false);
  const [form,           setForm]           = useState(FORM_ZERO);
  const [editId,         setEditId]         = useState(null);
  const [showForm,       setShowForm]       = useState(false);
  const [ordenacao,      setOrdenacao]      = useState("nome");
  const [filterStatus,   setFilterStatus]   = useState("Todos");
  const [pdfLoading,     setPdfLoading]     = useState(false);
  const [deleteTarget,   setDeleteTarget]   = useState(null);
  const [toast,          setToast]          = useState(null);

  // Importação
  const [showImport,     setShowImport]     = useState(false);
  const [importText,     setImportText]     = useState("");
  const [importLoading,  setImportLoading]  = useState(false);
  const [importResult,   setImportResult]   = useState(null);

  // Configurações
  const [showConfig,     setShowConfig]     = useState(false);
  const [configDraft,    setConfigDraft]    = useState(CONFIG_ZERO);

  // Admin
  const [showAdmin,      setShowAdmin]      = useState(false);
  const [adminDraft,     setAdminDraft]     = useState(ADMIN_ZERO);
  const [admin,          setAdmin]          = useState(ADMIN_ZERO);
  const [adminTab,       setAdminTab]       = useState("env");

  // Preview de foto (original vs tratada)
  const [photoPreview,   setPhotoPreview]   = useState(null);
  // { original: dataUrl, treated: dataUrl | null, loading: bool, index: number | null }

  const fileRef = useRef();

  // ── Boot: carregar storage ────────────────────────────────────────────────
  useEffect(() => {
    Promise.all([
      storageLoad(SK_PART, []),
      storageLoad(SK_CONFIG, CONFIG_ZERO),
      storageLoad(SK_ADMIN, ADMIN_ZERO),
    ]).then(([part, cfg, adm]) => {
      setParticipantes(part);
      setConfig(cfg);
      setAdmin({ ...ADMIN_ZERO, ...adm });
      setStorageReady(true);
    });
  }, []);

  // ── Persistir participantes ───────────────────────────────────────────────
  useEffect(() => {
    if (storageReady) storageSave(SK_PART, participantes);
  }, [participantes, storageReady]);

  // ── Toast ─────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(t);
  }, [toast]);
  const showToast = (msg, ok = true) => setToast({ msg, ok });

  // ── Fotos: selecionar, mostrar preview original vs tratada ────────────────
  const handleFotos = async (e) => {
    const files = Array.from(e.target.files);
    if (!files.length) return;
    e.target.value = "";

    for (const file of files) {
      let original;
      try { original = await compressImage(file); } catch { continue; }

      // Abre o painel de preview para esta foto
      const previewEntry = { original, treated: null, loading: !!config.prdFotos.trim(), approved: false };
      setPhotoPreview(previewEntry);

      // Se há PRD configurado, chama a IA para tratar
      if (config.prdFotos.trim()) {
        try {
          const treated = await processarFotoComIA(original, config.prdFotos);
          setPhotoPreview(prev => prev ? { ...prev, treated, loading: false } : null);
        } catch (err) {
          console.error("Erro tratamento foto:", err);
          setPhotoPreview(prev => prev ? { ...prev, treated: null, loading: false, error: true } : null);
        }
      }
      // Processa uma por vez — aguarda o usuário aceitar/rejeitar no modal
      break; // modal vai processar e chamar handleFotoApproved
    }
  };

  const handleFotoApproved = (dataUrl) => {
    setForm(f => ({ ...f, fotos: [...f.fotos, dataUrl] }));
    setPhotoPreview(null);
  };

  const removeFoto = (idx) =>
    setForm(f => ({ ...f, fotos: f.fotos.filter((_, i) => i !== idx) }));

  // ── CRUD participantes ────────────────────────────────────────────────────
  const abrirNovo    = () => { setForm(FORM_ZERO); setEditId(null); setShowForm(true); };
  const abrirEditar  = (p) => { setForm({ nome: p.nome, palpite: p.palpite, fotos: [...p.fotos] }); setEditId(p.id); setShowForm(true); };
  const fecharForm   = () => { setShowForm(false); setEditId(null); };

  const salvarForm = () => {
    const nomeCapit = capitalize(form.nome.trim());
    if (!nomeCapit) return showToast("Nome é obrigatório.", false);
    if (form.palpite && !/^\d{2}\/\d{2}$/.test(form.palpite))
      return showToast("Palpite deve ser MM/AA (ex: 03/25).", false);
    const jaExiste = participantes.some(x => x.nome.toLowerCase() === nomeCapit.toLowerCase() && x.id !== editId);
    if (jaExiste) return showToast(`"${nomeCapit}" já está cadastrado.`, false);

    // status não é armazenado — é calculado dinamicamente por calcStatus()
    if (editId !== null) {
      setParticipantes(prev => prev.map(x => x.id === editId ? { nome: nomeCapit, palpite: form.palpite, fotos: form.fotos, id: editId } : x));
      showToast("Participante atualizado! ✅");
    } else {
      setParticipantes(prev => [...prev, { nome: nomeCapit, palpite: form.palpite, fotos: form.fotos, id: Date.now() }]);
      showToast("Participante cadastrado! 🎉");
    }
    fecharForm(); setForm(FORM_ZERO);
  };

  const confirmarExcluir = () => {
    setParticipantes(prev => prev.filter(x => x.id !== deleteTarget));
    setDeleteTarget(null); showToast("Participante removido.");
  };

  // ── Importação IA ─────────────────────────────────────────────────────────
  const processarImport = async () => {
    if (!importText.trim()) return showToast("Cole o texto primeiro.", false);
    setImportLoading(true);
    try {
      const result = await interpretarLista(importText);
      const nomes = new Set(participantes.map(p => p.nome.toLowerCase()));
      setImportResult((result.participantes || []).map((p, i) => {
        const n = capitalize(p.nome || "");
        return { id: i, nome: n, palpite: p.palpite || "", checked: true, duplicado: nomes.has(n.toLowerCase()) };
      }));
    } catch { showToast("Erro ao processar com IA.", false); }
    setImportLoading(false);
  };

  const toggleImportItem = (id) => setImportResult(prev => prev.map(x => x.id === id ? { ...x, checked: !x.checked } : x));
  const toggleTodos = () => {
    const naodup = importResult.filter(x => !x.duplicado);
    const all = naodup.every(x => x.checked);
    setImportResult(prev => prev.map(x => x.duplicado ? x : { ...x, checked: !all }));
  };
  const salvarImport = () => {
    const sel = importResult.filter(x => x.checked && !x.duplicado);
    if (!sel.length) return showToast("Nenhum novo selecionado.", false);
    setParticipantes(prev => [...prev, ...sel.map(x => ({ nome: x.nome, palpite: x.palpite, fotos: [], id: Date.now() + Math.random() }))]);
    showToast(`${sel.length} participante(s) adicionado(s)! 🎉`);
    setShowImport(false); setImportText(""); setImportResult(null);
  };

  // ── Configurações ─────────────────────────────────────────────────────────
  const abrirConfig  = () => { setConfigDraft({ ...config }); setShowConfig(true); };
  const salvarConfig = () => {
    setConfig(configDraft);
    storageSave(SK_CONFIG, configDraft);
    setShowConfig(false);
    showToast("Configurações salvas! ⚙️");
  };

  // ── Admin ──────────────────────────────────────────────────────────────────
  const abrirAdmin  = () => { setAdminDraft({ ...admin }); setAdminTab("env"); setShowAdmin(true); };
  const salvarAdmin = () => {
    setAdmin(adminDraft);
    storageSave(SK_ADMIN, adminDraft);
    setShowAdmin(false);
    showToast("Configurações admin salvas! 🔐");
  };

  // ── PDF ───────────────────────────────────────────────────────────────────
  const gerarPDF = async () => {
    if (!participantes.length) return showToast("Nenhum participante cadastrado.", false);
    setPdfLoading(true);
    try {
      const jsPDF = await loadJsPDF();
      const doc = new jsPDF({ orientation: "p", unit: "mm", format: "a4" });
      const W = 210, H = 297;

      for (let i = 0; i < participantes.length; i++) {
        const p = participantes[i];
        if (i > 0) doc.addPage();
        doc.setFillColor(13, 13, 26); doc.rect(0, 0, W, H, "F");
        doc.setFillColor(233, 30, 140); doc.rect(0, 0, W, 20, "F");
        doc.setTextColor(255, 255, 255); doc.setFontSize(14); doc.setFont("helvetica", "bold");
        doc.text("BBB DA MALU", W / 2, 13, { align: "center" });
        doc.setFontSize(22); doc.setTextColor(245, 200, 66);
        doc.text(p.nome, W / 2, 34, { align: "center" });
        const pStatus = calcStatus(p.palpite);
        const pdfColor = STATUS_CONFIG[pStatus].pdf;
        doc.setFillColor(pdfColor[0], pdfColor[1], pdfColor[2]);
        doc.roundedRect(W / 2 - 28, 38, 56, 10, 3, 3, "F");
        doc.setFontSize(9); doc.setTextColor(255, 255, 255); doc.setFont("helvetica", "bold");
        doc.text(pStatus.toUpperCase(), W / 2, 45, { align: "center" });
        doc.setFontSize(11); doc.setFont("helvetica", "normal"); doc.setTextColor(180, 180, 220);
        doc.text(p.palpite ? `Palpite: ${p.palpite}` : "Sem palpite", W / 2, 56, { align: "center" });
        doc.setDrawColor(233, 30, 140); doc.setLineWidth(0.5); doc.line(20, 61, W - 20, 61);

        const fotos = p.fotos;
        if (!fotos.length) {
          doc.setTextColor(80, 80, 120); doc.setFontSize(11);
          doc.text("Sem fotos cadastradas", W / 2, 140, { align: "center" });
        } else {
          const cols = fotos.length === 1 ? 1 : fotos.length <= 4 ? 2 : 3;
          const rows = Math.ceil(fotos.length / cols);
          const margin = 14, gap = 4;
          const cellW = (W - margin * 2 - gap * (cols - 1)) / cols;
          const cellH = Math.min(cellW * 0.75, (H - 70 - margin - gap * (rows - 1) - 16) / rows);
          const startY = 65;
          for (let fi = 0; fi < fotos.length; fi++) {
            const col = fi % cols, row = Math.floor(fi / cols);
            const x = margin + col * (cellW + gap), y = startY + row * (cellH + gap);
            try { doc.addImage(fotos[fi], "JPEG", x, y, cellW, cellH, `img_${i}_${fi}`, "FAST"); } catch {}
            doc.setDrawColor(233, 30, 140); doc.setLineWidth(0.3); doc.rect(x, y, cellW, cellH);
          }
        }
        doc.setDrawColor(50, 50, 90); doc.setLineWidth(0.3); doc.line(14, H - 12, W - 14, H - 12);
        doc.setFontSize(7); doc.setFont("helvetica", "normal"); doc.setTextColor(70, 70, 110);
        doc.text(`BBB da Malu  |  Pagina ${i + 1} de ${participantes.length}`, W / 2, H - 6, { align: "center" });
      }
      doc.save("BBB_da_Malu.pdf");
      showToast("PDF gerado! 📄");
    } catch { showToast("Erro ao gerar PDF.", false); }
    setPdfLoading(false);
  };

  // ── Lista filtrada — status calculado dinamicamente ───────────────────────
  const lista = [...participantes]
    .map(p => ({ ...p, status: calcStatus(p.palpite) }))
    .filter(p => filterStatus === "Todos" || p.status === filterStatus)
    .sort((a, b) => {
      if (ordenacao === "nome") return a.nome.localeCompare(b.nome, "pt-BR");
      const da = parseDate(a.palpite), db = parseDate(b.palpite);
      if (!da && !db) return 0; if (!da) return 1; if (!db) return -1; return da - db;
    });

  // ════════════════════════════════════════════════════════════════════════════
  // RENDER
  // ════════════════════════════════════════════════════════════════════════════
  return (
    <div style={{ minHeight: "100vh", background: DARK, fontFamily: "'Georgia', serif", color: "#fff" }}>

      {/* ── Toast ── */}
      {toast && (
        <div style={{ position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)", background: toast.ok ? "#1a4a2e" : "#4a1a1a", border: `1px solid ${toast.ok ? "#27ae60" : "#c0392b"}`, color: "#fff", padding: "10px 24px", borderRadius: 10, zIndex: 9999, fontSize: 14, boxShadow: "0 4px 20px rgba(0,0,0,0.6)", whiteSpace: "nowrap", pointerEvents: "none" }}>
          {toast.msg}
        </div>
      )}

      {/* ── Modal: Confirmar exclusão ── */}
      {deleteTarget !== null && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", zIndex: 200, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ background: CARD_BG, borderRadius: 14, padding: 30, maxWidth: 340, width: "90%", border: "1px solid #c0392b88", textAlign: "center" }}>
            <div style={{ fontSize: 38, marginBottom: 12 }}>🗑️</div>
            <p style={{ margin: "0 0 22px", fontSize: 15, lineHeight: 1.5 }}>Remover este participante?</p>
            <div style={{ display: "flex", gap: 10, justifyContent: "center" }}>
              <button onClick={confirmarExcluir} style={btnStyle("#c0392b")}>Remover</button>
              <button onClick={() => setDeleteTarget(null)} style={btnStyle("#333")}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Modal: Preview Original vs Tratada ── */}
      {photoPreview && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.95)", zIndex: 300, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}>
          <div style={{ background: CARD_BG, borderRadius: 16, padding: 24, width: "100%", maxWidth: 680, border: `1px solid ${PINK}55`, boxShadow: `0 0 60px ${PINK}22` }}>
            <h3 style={{ margin: "0 0 6px", color: GOLD, fontSize: 18 }}>🖼️ Revisão de Foto</h3>
            <p style={{ margin: "0 0 18px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>
              {config.prdFotos.trim()
                ? "Compare a foto original com a versão tratada pela IA. Escolha qual salvar."
                : "Sem PRD de fotos configurado — apenas a foto original está disponível."}
            </p>

            <div style={{ display: "grid", gridTemplateColumns: config.prdFotos.trim() ? "1fr 1fr" : "1fr", gap: 16, marginBottom: 20 }}>
              {/* Original */}
              <div>
                <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 6, textAlign: "center", letterSpacing: 1, textTransform: "uppercase" }}>Original</div>
                <img src={photoPreview.original} alt="original"
                  style={{ width: "100%", borderRadius: 8, border: "2px solid #334", display: "block", maxHeight: 280, objectFit: "contain", background: "#0a0a18" }} />
              </div>

              {/* Tratada */}
              {config.prdFotos.trim() && (
                <div>
                  <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", marginBottom: 6, textAlign: "center", letterSpacing: 1, textTransform: "uppercase" }}>
                    Tratada pela IA {photoPreview.loading && <span style={{ color: PINK }}>⏳</span>}
                  </div>
                  <div style={{ width: "100%", borderRadius: 8, border: `2px solid ${photoPreview.treated ? PINK : "#334"}`, minHeight: 120, display: "flex", alignItems: "center", justifyContent: "center", background: "#0a0a18", overflow: "hidden", maxHeight: 280 }}>
                    {photoPreview.loading ? (
                      <div style={{ textAlign: "center", padding: 20, color: "rgba(255,255,255,0.3)" }}>
                        <div style={{ fontSize: 28, marginBottom: 8 }}>✨</div>
                        <div style={{ fontSize: 12 }}>Processando com IA...</div>
                      </div>
                    ) : photoPreview.error ? (
                      <div style={{ textAlign: "center", padding: 20, color: "#c0392b" }}>
                        <div style={{ fontSize: 24, marginBottom: 6 }}>⚠️</div>
                        <div style={{ fontSize: 11 }}>Erro no tratamento</div>
                      </div>
                    ) : photoPreview.treated ? (
                      <img src={photoPreview.treated} alt="tratada"
                        style={{ width: "100%", display: "block", maxHeight: 280, objectFit: "contain" }} />
                    ) : null}
                  </div>
                </div>
              )}
            </div>

            {/* Ações */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <button
                onClick={() => handleFotoApproved(photoPreview.original)}
                style={{ ...btnStyle("#2a2a4a", "#fff", { border: "1px solid #446" }), flex: 1 }}
              >
                ✅ Usar Original
              </button>
              {config.prdFotos.trim() && photoPreview.treated && !photoPreview.loading && (
                <button
                  onClick={() => handleFotoApproved(photoPreview.treated)}
                  style={{ ...btnStyle(PINK), flex: 1 }}
                >
                  ✨ Usar Tratada
                </button>
              )}
              <button
                onClick={() => setPhotoPreview(null)}
                style={btnStyle("#333")}
              >
                Cancelar
              </button>
            </div>

            {photoPreview.loading && (
              <p style={{ margin: "12px 0 0", fontSize: 11, color: "rgba(255,255,255,0.25)", textAlign: "center" }}>
                Você pode usar a original enquanto a IA processa...
              </p>
            )}
          </div>
        </div>
      )}

      {/* ── Modal: Configurações ── */}
      {showConfig && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.92)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
          onClick={e => { if (e.target === e.currentTarget) setShowConfig(false); }}
        >
          <div style={{ background: CARD_BG, borderRadius: 16, padding: 28, width: "100%", maxWidth: 560, border: "1px solid #445", boxShadow: "0 0 50px rgba(255,255,255,0.05)", maxHeight: "92vh", overflowY: "auto" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
              <span style={{ fontSize: 22 }}>⚙️</span>
              <h2 style={{ margin: 0, color: GOLD, fontSize: 20 }}>Configurações</h2>
            </div>
            <p style={{ margin: "0 0 20px", color: "rgba(255,255,255,0.35)", fontSize: 12 }}>
              Parâmetros gerais do aplicativo BBB da Malu.
            </p>

            {/* Seção: PRD de Fotos */}
            <div style={{ background: "#0f0f24", borderRadius: 10, padding: "16px 18px", border: "1px solid #2a2a4a", marginBottom: 20 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                <span style={{ fontSize: 18 }}>📷</span>
                <span style={{ fontWeight: "bold", color: "#ddd", fontSize: 15 }}>PRD — Tratamento de Fotos</span>
              </div>
              <p style={{ margin: "0 0 10px", color: "rgba(255,255,255,0.35)", fontSize: 11, lineHeight: 1.5 }}>
                Descreva como a IA deve tratar as fotos ao serem adicionadas. Ao adicionar uma foto, será exibido um preview lado a lado (original × tratada) para você aprovar.
                Deixe em branco para desativar o tratamento automático.
              </p>
              <textarea
                value={configDraft.prdFotos}
                onChange={e => setConfigDraft(d => ({ ...d, prdFotos: e.target.value }))}
                placeholder={`Exemplos de instruções:\n\n• Remova o fundo da imagem e coloque fundo branco\n• Aplique filtro vintage com tons quentes\n• Ajuste brilho +20%, contraste +10% e nitidez suave\n• Recorte centralizado no rosto (portrait 4:3)\n• Converta para preto e branco com alto contraste`}
                style={{ ...inputStyle, height: 160, resize: "vertical", fontFamily: "monospace", fontSize: 12, lineHeight: 1.5, marginBottom: 0 }}
              />
              {configDraft.prdFotos.trim() && (
                <div style={{ marginTop: 8, padding: "6px 10px", background: "#1a2a1a", borderRadius: 6, fontSize: 11, color: "#27ae60" }}>
                  ✅ Tratamento ativo — a IA processará cada nova foto adicionada
                </div>
              )}
              {!configDraft.prdFotos.trim() && (
                <div style={{ marginTop: 8, padding: "6px 10px", background: "#1a1a2a", borderRadius: 6, fontSize: 11, color: "rgba(255,255,255,0.3)" }}>
                  ○ Tratamento inativo — fotos serão salvas sem processamento
                </div>
              )}
            </div>

            {/* Espaço para futuras configurações */}
            <div style={{ padding: "12px 18px", border: "1px dashed #2a2a4a", borderRadius: 10, marginBottom: 20, textAlign: "center" }}>
              <span style={{ color: "rgba(255,255,255,0.2)", fontSize: 12 }}>Mais configurações serão adicionadas aqui</span>
            </div>

            <div style={{ display: "flex", gap: 10 }}>
              <button onClick={salvarConfig} style={{ ...btnStyle(PINK), flex: 1 }}>💾 Salvar Configurações</button>
              <button onClick={() => setShowConfig(false)} style={btnStyle("#444")}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Modal: Formulário cadastro/edição ── */}
      {showForm && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
          onClick={e => { if (e.target === e.currentTarget) fecharForm(); }}
        >
          <div style={{ background: CARD_BG, borderRadius: 16, padding: 28, width: "100%", maxWidth: 480, border: `1px solid ${PINK}55`, boxShadow: `0 0 50px ${PINK}22`, maxHeight: "92vh", overflowY: "auto" }}>
            <h2 style={{ margin: "0 0 6px", color: GOLD, fontSize: 20 }}>
              {editId !== null ? "✏️ Editar" : "➕ Novo"} Participante
            </h2>
            <p style={{ margin: "0 0 18px", color: "rgba(255,255,255,0.35)", fontSize: 12 }}>Clique fora ou em Cancelar para fechar sem salvar.</p>

            <label style={labelStyle}>Nome *</label>
            <input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))}
              onKeyDown={e => e.key === "Enter" && salvarForm()}
              placeholder="Nome do participante" style={inputStyle} autoFocus />

            <label style={labelStyle}>Palpite (MM/AA)
              {editId !== null && form.palpite && (
                <span style={{ marginLeft: 8, color: "#e67e22", fontSize: 10 }}>🔒 bloqueado após definido</span>
              )}
            </label>
            <input
              value={form.palpite}
              onChange={e => {
                // Bloqueia alteração se estiver editando e já tiver palpite salvo
                const original = participantes.find(x => x.id === editId);
                if (editId !== null && original && original.palpite) return;
                setForm(f => ({ ...f, palpite: maskPalpite(e.target.value) }));
              }}
              placeholder="ex: 03/25" maxLength={5}
              readOnly={editId !== null && !!participantes.find(x => x.id === editId)?.palpite}
              style={{
                ...inputStyle,
                ...(editId !== null && !!participantes.find(x => x.id === editId)?.palpite
                  ? { background: "#111120", color: "#666", cursor: "not-allowed", border: "1px solid #2a2a3a" }
                  : {})
              }}
            />

            {/* Preview de status calculado */}
            {(() => {
              const s = calcStatus(form.palpite);
              const cfg = STATUS_CONFIG[s];
              return (
                <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 12px", borderRadius: 8, background: cfg.bg, border: `1px solid ${cfg.color}55`, marginBottom: 4 }}>
                  <span style={{ fontSize: 16 }}>{cfg.icon}</span>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: "bold", color: cfg.color }}>{s}</div>
                    <div style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>
                      {s === "Na Casa"    && (form.palpite ? "Palpite em mês futuro" : "Sem palpite definido")}
                      {s === "No Paredão" && "Palpite no mês atual — está no paredão!"}
                      {s === "Eliminado"  && "Palpite em mês já passado"}
                    </div>
                  </div>
                </div>
              );
            })()}

            <label style={labelStyle}>
              Fotos ({form.fotos.length})
              {config.prdFotos.trim() && (
                <span style={{ marginLeft: 8, color: PINK, fontSize: 10 }}>✨ Tratamento IA ativo</span>
              )}
            </label>
            <button onClick={() => fileRef.current.click()} style={{ ...btnStyle("#334"), marginBottom: 10, width: "100%" }}>
              📷 Adicionar Foto
            </button>
            <input ref={fileRef} type="file" accept="image/*" multiple onChange={handleFotos} style={{ display: "none" }} />

            {form.fotos.length > 0 && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 6, marginBottom: 16 }}>
                {form.fotos.map((src, i) => (
                  <div key={i} style={{ position: "relative" }}>
                    <img src={src} alt={`foto ${i + 1}`} style={{ width: "100%", aspectRatio: "1", objectFit: "cover", borderRadius: 6, display: "block" }} />
                    <button onClick={() => removeFoto(i)}
                      style={{ position: "absolute", top: 3, right: 3, background: "#c0392b", color: "#fff", border: "none", borderRadius: "50%", width: 20, height: 20, cursor: "pointer", fontSize: 11, lineHeight: "20px", textAlign: "center", padding: 0 }}>✕</button>
                  </div>
                ))}
              </div>
            )}

            <div style={{ display: "flex", gap: 10, marginTop: 8 }}>
              <button onClick={salvarForm} style={{ ...btnStyle(PINK), flex: 1 }}>💾 Salvar</button>
              <button onClick={fecharForm} style={{ ...btnStyle("#444"), flex: 1 }}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ── Modal: Importar lista ── */}
      {showImport && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.92)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
          onClick={e => { if (e.target === e.currentTarget && !importLoading) { setShowImport(false); setImportResult(null); setImportText(""); } }}
        >
          <div style={{ background: CARD_BG, borderRadius: 16, padding: 28, width: "100%", maxWidth: 560, border: `1px solid ${GOLD}44`, boxShadow: `0 0 50px ${GOLD}11`, maxHeight: "92vh", overflowY: "auto" }}>
            <h2 style={{ margin: "0 0 6px", color: GOLD, fontSize: 20 }}>🤖 Importar Lista via IA</h2>
            <p style={{ margin: "0 0 16px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Cole sua lista em qualquer formato. A IA identifica nomes e palpites.</p>

            {!importResult ? (
              <>
                <textarea value={importText} onChange={e => setImportText(e.target.value)}
                  placeholder={"Cole aqui a lista, por exemplo:\n\nAna Silva - março/25\nJoão Pedro: 04/25\nMaria Fernanda (maio de 2025)\n1. Carlos Eduardo - 06/25"}
                  style={{ ...inputStyle, height: 180, resize: "vertical", fontFamily: "monospace", fontSize: 13, marginBottom: 16 }}
                  disabled={importLoading} />
                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={processarImport} disabled={importLoading}
                    style={{ ...btnStyle(GOLD, "#111"), flex: 1, opacity: importLoading ? 0.6 : 1 }}>
                    {importLoading ? "⏳ Processando..." : "✨ Identificar com IA"}
                  </button>
                  <button onClick={() => { setShowImport(false); setImportText(""); }} style={btnStyle("#444")}>Cancelar</button>
                </div>
              </>
            ) : (
              <>
                <div style={{ marginBottom: 12, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
                  <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 13 }}>
                    {importResult.length} encontrado(s) •{" "}
                    <span style={{ color: "#27ae60" }}>{importResult.filter(x => !x.duplicado).length} novos</span>
                    {importResult.filter(x => x.duplicado).length > 0 && <span style={{ color: "#e67e22" }}> • {importResult.filter(x => x.duplicado).length} já cadastrado(s)</span>}
                  </span>
                  <button onClick={toggleTodos}
                    style={{ padding: "4px 12px", borderRadius: 6, border: `1px solid ${PINK}`, background: "transparent", color: PINK, cursor: "pointer", fontSize: 12, fontWeight: "bold" }}>
                    {importResult.filter(x => !x.duplicado).every(x => x.checked) ? "Desmarcar todos" : "Marcar todos"}
                  </button>
                </div>
                <div style={{ maxHeight: 300, overflowY: "auto", marginBottom: 16, borderRadius: 8, border: "1px solid #2a2a4a" }}>
                  {importResult.map(item => (
                    <div key={item.id} onClick={() => !item.duplicado && toggleImportItem(item.id)}
                      style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderBottom: "1px solid #1a1a35", cursor: item.duplicado ? "default" : "pointer", background: item.duplicado ? "rgba(230,126,34,0.07)" : item.checked ? "rgba(233,30,140,0.07)" : "transparent" }}>
                      <div style={{ width: 20, height: 20, borderRadius: 5, flexShrink: 0, border: `2px solid ${item.duplicado ? "#e67e22" : item.checked ? PINK : "#444"}`, background: item.duplicado ? "transparent" : item.checked ? PINK : "transparent", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, color: "#fff" }}>
                        {item.duplicado ? "—" : item.checked ? "✓" : ""}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 14, fontWeight: "bold", color: item.duplicado ? "#e67e22" : "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{item.nome}</div>
                        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)" }}>
                          {item.palpite ? `Palpite: ${item.palpite}` : "Sem palpite"}
                          {item.palpite && (() => { const s = calcStatus(item.palpite); const cfg = STATUS_CONFIG[s]; return <span style={{ marginLeft: 8, color: cfg.color }}>{cfg.icon} {s}</span>; })()}
                          {item.duplicado && <span style={{ color: "#e67e22", marginLeft: 8 }}>⚠ já cadastrado</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button onClick={salvarImport} style={{ ...btnStyle(PINK), flex: 1 }}>
                    💾 Salvar {importResult.filter(x => x.checked && !x.duplicado).length} selecionado(s)
                  </button>
                  <button onClick={() => setImportResult(null)} style={btnStyle("#444")}>← Voltar</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          MODAL: ADMIN
      ══════════════════════════════════════════════════════════════════════ */}
      {showAdmin && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.95)", zIndex: 500, display: "flex", alignItems: "center", justifyContent: "center", padding: 16 }}
          onClick={e => { if (e.target === e.currentTarget) setShowAdmin(false); }}>
          <div style={{ background: "#0d0d1a", borderRadius: 16, width: "100%", maxWidth: 640, border: "1px solid #c0392b66", boxShadow: "0 0 60px rgba(192,57,43,0.2)", maxHeight: "94vh", display: "flex", flexDirection: "column" }}>

            {/* Header do modal */}
            <div style={{ padding: "20px 24px 0", borderBottom: "1px solid #1a1a35", paddingBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 22 }}>🔐</span>
                <div>
                  <h2 style={{ margin: 0, color: "#e74c3c", fontSize: 20 }}>Painel Admin</h2>
                  <p style={{ margin: 0, fontSize: 11, color: "rgba(255,255,255,0.3)" }}>Tokens, banco de dados e configurações de deploy</p>
                </div>
                <div style={{ marginLeft: "auto" }}>
                  <span style={{ padding: "3px 10px", borderRadius: 12, fontSize: 11, fontWeight: "bold",
                    background: adminDraft.env === "development" ? "#1a3a4a" : "#2a1a3a",
                    color: adminDraft.env === "development" ? "#3498db" : "#9b59b6",
                    border: `1px solid ${adminDraft.env === "development" ? "#3498db55" : "#9b59b655"}` }}>
                    {adminDraft.env === "development" ? "🐳 DEV" : "🚀 PROD"}
                  </span>
                </div>
              </div>

              {/* Tabs */}
              <div style={{ display: "flex", gap: 4, marginTop: 14, flexWrap: "wrap" }}>
                {[
                  ["env",      "🌍 Ambiente"],
                  ["postgres", "🐘 PostgreSQL"],
                  ["supabase", "⚡ Supabase"],
                  ["vercel",   "▲ Vercel"],
                  ["github",   "🐙 GitHub"],
                  ["app",      "⚙️ App"],
                ].map(([key, label]) => (
                  <button key={key} onClick={() => setAdminTab(key)}
                    style={{ padding: "6px 14px", borderRadius: 8, border: "none", cursor: "pointer", fontSize: 12, fontWeight: "bold",
                      background: adminTab === key ? "#e74c3c" : "#1a1a2e",
                      color: adminTab === key ? "#fff" : "rgba(255,255,255,0.45)",
                      transition: "all .15s" }}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Conteúdo das tabs */}
            <div style={{ overflowY: "auto", padding: "16px 24px", flex: 1 }}>

              {/* ── Ambiente ── */}
              {adminTab === "env" && (
                <div>
                  <p style={{ margin: "0 0 16px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>
                    Define se o app usa o banco local (Docker/PostgreSQL) ou produção (Supabase).
                  </p>
                  <div style={{ display: "flex", gap: 12, marginBottom: 20 }}>
                    {[["development", "🐳 Development", "PostgreSQL local via Docker"], ["production", "🚀 Production", "Supabase na Vercel"]].map(([val, label, desc]) => (
                      <div key={val} onClick={() => setAdminDraft(d => ({ ...d, env: val }))}
                        style={{ flex: 1, padding: "14px 16px", borderRadius: 10, cursor: "pointer", transition: "all .15s",
                          border: `2px solid ${adminDraft.env === val ? (val === "development" ? "#3498db" : "#9b59b6") : "#2a2a4a"}`,
                          background: adminDraft.env === val ? (val === "development" ? "#0a1a2a" : "#1a0a2a") : "#111122" }}>
                        <div style={{ fontSize: 20, marginBottom: 6 }}>{label.split(" ")[0]}</div>
                        <div style={{ fontWeight: "bold", color: "#fff", fontSize: 13 }}>{label.split(" ").slice(1).join(" ")}</div>
                        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 4 }}>{desc}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ padding: 14, borderRadius: 8, background: "#0a0a18", border: "1px solid #2a2a4a", fontSize: 12, color: "rgba(255,255,255,0.4)" }}>
                    <strong style={{ color: "rgba(255,255,255,0.6)" }}>Variável gerada:</strong><br />
                    <code style={{ color: adminDraft.env === "development" ? "#3498db" : "#9b59b6" }}>
                      NODE_ENV={adminDraft.env}
                    </code>
                  </div>
                </div>
              )}

              {/* ── PostgreSQL ── */}
              {adminTab === "postgres" && (
                <div>
                  <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Usado em <strong style={{color:"#3498db"}}>desenvolvimento</strong> com Docker Compose.</p>
                  <div style={{ marginBottom: 8, padding: "8px 12px", borderRadius: 6, background: "#0a1525", border: "1px solid #3498db33", fontSize: 11, color: "#3498db" }}>
                    DATABASE_URL=postgresql://{adminDraft.pgUser||"postgres"}:{adminDraft.pgPassword||"****"}@{adminDraft.pgHost||"localhost"}:{adminDraft.pgPort||"5432"}/{adminDraft.pgDb||"bbb_malu"}
                  </div>
                  {[
                    ["pgHost", "Host", "localhost"],
                    ["pgPort", "Porta", "5432"],
                    ["pgDb", "Database", "bbb_malu"],
                    ["pgUser", "Usuário", "postgres"],
                    ["pgPassword", "Senha", "••••••••"],
                  ].map(([key, label, placeholder]) => (
                    <div key={key}>
                      <label style={labelStyle}>{label}</label>
                      <input type={key === "pgPassword" ? "password" : "text"} value={adminDraft[key]}
                        onChange={e => setAdminDraft(d => ({ ...d, [key]: e.target.value }))}
                        placeholder={placeholder} style={inputStyle} />
                    </div>
                  ))}
                </div>
              )}

              {/* ── Supabase ── */}
              {adminTab === "supabase" && (
                <div>
                  <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Usado em <strong style={{color:"#9b59b6"}}>produção</strong>. Acesse <a href="https://supabase.com/dashboard" target="_blank" style={{color:"#9b59b6"}}>supabase.com/dashboard</a> para obter as chaves.</p>
                  {[
                    ["supabaseUrl",        "Project URL",          "https://xxxx.supabase.co"],
                    ["supabaseAnonKey",     "Anon / Public Key",    "eyJhbGci..."],
                    ["supabaseServiceKey",  "Service Role Key 🔒",  "eyJhbGci..."],
                  ].map(([key, label, placeholder]) => (
                    <div key={key}>
                      <label style={labelStyle}>{label}</label>
                      <input type="password" value={adminDraft[key]}
                        onChange={e => setAdminDraft(d => ({ ...d, [key]: e.target.value }))}
                        placeholder={placeholder} style={inputStyle} />
                    </div>
                  ))}
                  <div style={{ marginTop: 12, padding: "8px 12px", borderRadius: 6, background: "#1a0a2a", border: "1px solid #9b59b633", fontSize: 11, color: "#9b59b6" }}>
                    ⚠️ A Service Role Key tem acesso total ao banco. Nunca exponha no frontend.
                  </div>
                </div>
              )}

              {/* ── Vercel ── */}
              {adminTab === "vercel" && (
                <div>
                  <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Token e IDs para deploy na Vercel via CI/CD. Gere em <a href="https://vercel.com/account/tokens" target="_blank" style={{color:"#fff"}}>vercel.com/account/tokens</a>.</p>
                  {[
                    ["vercelToken",     "Vercel Token",      "xxxxxxxxxxxxxxxx"],
                    ["vercelProjectId", "Project ID",        "prj_xxxxxxx"],
                    ["vercelOrgId",     "Org / Team ID",     "team_xxxxxxx"],
                  ].map(([key, label, placeholder]) => (
                    <div key={key}>
                      <label style={labelStyle}>{label}</label>
                      <input type="password" value={adminDraft[key]}
                        onChange={e => setAdminDraft(d => ({ ...d, [key]: e.target.value }))}
                        placeholder={placeholder} style={inputStyle} />
                    </div>
                  ))}
                </div>
              )}

              {/* ── GitHub ── */}
              {adminTab === "github" && (
                <div>
                  <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Repositório e token para CI/CD com GitHub Actions.</p>
                  {[
                    ["githubRepo",  "Repositório (user/repo)", "seunome/bbb-da-malu"],
                    ["githubToken", "Personal Access Token",   "ghp_xxxxxxxx"],
                  ].map(([key, label, placeholder]) => (
                    <div key={key}>
                      <label style={labelStyle}>{label}</label>
                      <input type={key === "githubToken" ? "password" : "text"} value={adminDraft[key]}
                        onChange={e => setAdminDraft(d => ({ ...d, [key]: e.target.value }))}
                        placeholder={placeholder} style={inputStyle} />
                    </div>
                  ))}
                </div>
              )}

              {/* ── App ── */}
              {adminTab === "app" && (
                <div>
                  <p style={{ margin: "0 0 4px", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>Configurações gerais do aplicativo.</p>
                  {[
                    ["appName", "Nome do App",  "BBB da Malu"],
                    ["appUrl",  "URL Pública",  "https://bbb-da-malu.vercel.app"],
                  ].map(([key, label, placeholder]) => (
                    <div key={key}>
                      <label style={labelStyle}>{label}</label>
                      <input type="text" value={adminDraft[key]}
                        onChange={e => setAdminDraft(d => ({ ...d, [key]: e.target.value }))}
                        placeholder={placeholder} style={inputStyle} />
                    </div>
                  ))}
                  <div style={{ marginTop: 16, padding: 14, borderRadius: 8, background: "#0a0a18", border: "1px solid #2a2a4a" }}>
                    <div style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", marginBottom: 8, fontWeight: "bold" }}>📋 .env gerado</div>
                    <pre style={{ margin: 0, fontSize: 10, color: "#7f8c8d", lineHeight: 1.6, overflowX: "auto" }}>{
`NODE_ENV=${adminDraft.env}
APP_NAME="${adminDraft.appName}"
APP_URL="${adminDraft.appUrl}"

# Dev
DATABASE_URL="postgresql://${adminDraft.pgUser}:${adminDraft.pgPassword}@${adminDraft.pgHost}:${adminDraft.pgPort}/${adminDraft.pgDb}"

# Prod
NEXT_PUBLIC_SUPABASE_URL="${adminDraft.supabaseUrl}"
NEXT_PUBLIC_SUPABASE_ANON_KEY="${adminDraft.supabaseAnonKey}"
SUPABASE_SERVICE_ROLE_KEY="${adminDraft.supabaseServiceKey}"

# Deploy
VERCEL_TOKEN="${adminDraft.vercelToken}"
VERCEL_PROJECT_ID="${adminDraft.vercelProjectId}"
VERCEL_ORG_ID="${adminDraft.vercelOrgId}"
GITHUB_REPO="${adminDraft.githubRepo}"`
                    }</pre>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div style={{ padding: "14px 24px", borderTop: "1px solid #1a1a35", display: "flex", gap: 10 }}>
              <button onClick={salvarAdmin} style={{ ...btnStyle("#e74c3c"), flex: 1 }}>🔐 Salvar Admin</button>
              <button onClick={() => setShowAdmin(false)} style={btnStyle("#333")}>Cancelar</button>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════════
          HEADER
      ══════════════════════════════════════════════════════════════════════ */}
      <div style={{ background: `linear-gradient(135deg, ${PINK} 0%, #7b1255 60%, ${DARK} 100%)`, padding: "28px 24px 24px", textAlign: "center", position: "relative" }}>
        {/* Botão configurações — canto superior direito */}
        <div style={{ position: "absolute", top: 16, right: 16, display: "flex", gap: 6 }}>
          <button onClick={abrirAdmin} title="Admin"
            style={{ background: "rgba(192,57,43,0.25)", border: "1px solid rgba(192,57,43,0.5)", borderRadius: 8, padding: "7px 10px", cursor: "pointer", fontSize: 16, color: "#e74c3c", transition: "background .2s" }}
            onMouseEnter={e => e.currentTarget.style.background = "rgba(192,57,43,0.45)"}
            onMouseLeave={e => e.currentTarget.style.background = "rgba(192,57,43,0.25)"}
          >🔐</button>
          <button onClick={abrirConfig} title="Configurações"
            style={{ background: "rgba(255,255,255,0.1)", border: "1px solid rgba(255,255,255,0.2)", borderRadius: 8, padding: "7px 10px", cursor: "pointer", fontSize: 18, color: "#fff", transition: "background .2s" }}
            onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.2)"}
            onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.1)"}
          >⚙️</button>
        </div>

        <div style={{ fontSize: 38, marginBottom: 6 }}>⭐ 🎂 ⭐</div>
        <h1 style={{ margin: 0, fontSize: 36, fontWeight: "bold", letterSpacing: 3, color: GOLD, textShadow: `0 2px 24px ${PINK}99` }}>BBB DA MALU</h1>
        <p style={{ margin: "8px 0 22px", color: "rgba(255,255,255,0.65)", fontSize: 14 }}>Bolão de Aniversário • Quem vai acertar a data? 🎯</p>
        <div style={{ display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" }}>
          <button onClick={abrirNovo} style={btnStyle(PINK)}>+ Cadastrar</button>
          <button onClick={() => { setShowImport(true); setImportResult(null); setImportText(""); }} style={btnStyle(GOLD, "#111")}>🤖 Importar Lista</button>
          <button onClick={gerarPDF} disabled={pdfLoading} style={btnStyle("#334", "#fff", { opacity: pdfLoading ? 0.6 : 1, border: "1px solid #556" })}>
            {pdfLoading ? "⏳ PDF..." : "📄 Gerar PDF"}
          </button>
        </div>
      </div>

      {/* Info bar */}
      <div style={{ background: "#0a0a18", borderBottom: "1px solid #1a1a35", padding: "7px 16px", textAlign: "center" }}>
        {(() => {
          const counts = { "Na Casa": 0, "No Paredão": 0, "Eliminado": 0, "Sem Palpite": 0 };
          participantes.forEach(p => { const s = calcStatus(p.palpite); if (counts[s] !== undefined) counts[s]++; });
          return (
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>
              💾 Salvos automaticamente &nbsp;·&nbsp;
              <span style={{ color: STATUS_CONFIG["Na Casa"].color }}>🏠 {counts["Na Casa"]}</span>
              &nbsp;·&nbsp;
              <span style={{ color: STATUS_CONFIG["No Paredão"].color }}>🔥 {counts["No Paredão"]}</span>
              &nbsp;·&nbsp;
              <span style={{ color: STATUS_CONFIG["Eliminado"].color }}>❌ {counts["Eliminado"]}</span>
              &nbsp;·&nbsp;
              <span style={{ color: STATUS_CONFIG["Sem Palpite"].color }}>❓ {counts["Sem Palpite"]} sem palpite</span>
              {config.prdFotos.trim() && <span style={{ color: PINK }}> &nbsp;·&nbsp; ✨ IA ativa</span>}
            </span>
          );
        })()}
      </div>

      {/* ── Controles ── */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "20px 16px 0" }}>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 20 }}>
          <span style={{ color: GOLD, fontWeight: "bold", fontSize: 13 }}>Ordenar:</span>
          {[["nome", "🔤 Alfabético"], ["palpite", "📅 Palpite"]].map(([v, l]) => (
            <button key={v} onClick={() => setOrdenacao(v)}
              style={{ padding: "6px 14px", borderRadius: 20, border: "none", cursor: "pointer", fontWeight: "bold", fontSize: 12, background: ordenacao === v ? PINK : "#222", color: "#fff" }}>{l}</button>
          ))}
          <span style={{ color: GOLD, fontWeight: "bold", fontSize: 13, marginLeft: 8 }}>Filtrar:</span>
          {["Todos", "Na Casa", "No Paredão", "Eliminado", "Sem Palpite"].map(s => {
            const cfg = STATUS_CONFIG[s];
            const active = filterStatus === s;
            return (
              <button key={s} onClick={() => setFilterStatus(s)}
                style={{ padding: "6px 14px", borderRadius: 20, border: "none", cursor: "pointer", fontWeight: "bold", fontSize: 12,
                  background: active ? (cfg ? cfg.color : "#555") : "#222", color: "#fff" }}>
                {cfg ? cfg.icon + " " : ""}{s}
              </button>
            );
          })}
          <span style={{ marginLeft: "auto", color: "rgba(255,255,255,0.4)", fontSize: 12 }}>
            {lista.length} / {participantes.length}
          </span>
        </div>

        {lista.length === 0 ? (
          <div style={{ textAlign: "center", padding: "70px 0", color: "rgba(255,255,255,0.25)" }}>
            <div style={{ fontSize: 52, marginBottom: 14 }}>🎂</div>
            <p style={{ fontSize: 17, lineHeight: 1.6 }}>
              {participantes.length === 0 ? <>Nenhum participante ainda.<br />Cadastre um ou importe uma lista!</> : "Nenhum participante neste filtro."}
            </p>
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(270px, 1fr))", gap: 18, paddingBottom: 48 }}>
            {lista.map(p => (
              <Card key={p.id} p={p}
                onEdit={() => abrirEditar(p)}
                onDelete={() => setDeleteTarget(p.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Card ──────────────────────────────────────────────────────────────────
function Card({ p, onEdit, onDelete }) {
  const status = calcStatus(p.palpite);
  const scfg   = STATUS_CONFIG[status];
  const isElim = status === "Eliminado";
  return (
    <div
      style={{ background: CARD_BG, borderRadius: 14, overflow: "hidden",
        border: `1px solid ${scfg.color}44`,
        boxShadow: "0 4px 20px rgba(0,0,0,0.4)", transition: "transform .2s, box-shadow .2s",
        opacity: isElim ? 0.72 : 1 }}
      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = `0 8px 32px ${scfg.color}44`; }}
      onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,0,0,0.4)"; }}
    >
      <div style={{ height: 165, background: "#0a0a18", position: "relative", overflow: "hidden" }}>
        <PhotoMosaic fotos={p.fotos} />
        {/* Ribbon de status */}
        <div style={{ position: "absolute", top: 12, right: -30,
          background: scfg.color, color: "#fff", fontSize: 8, fontWeight: "bold",
          padding: "3px 36px", transform: "rotate(35deg)", letterSpacing: 1.2,
          whiteSpace: "nowrap" }}>
          {status.toUpperCase()}
        </div>
      </div>
      <div style={{ padding: "14px 14px 12px" }}>
        <h3 style={{ margin: "0 0 4px", fontSize: 17, color: GOLD, wordBreak: "break-word" }}>{p.nome}</h3>

        {/* Badge de status */}
        <div style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 10px", borderRadius: 20,
          background: scfg.bg, border: `1px solid ${scfg.color}66`, marginBottom: 8 }}>
          <span style={{ fontSize: 12 }}>{scfg.icon}</span>
          <span style={{ fontSize: 11, fontWeight: "bold", color: scfg.color }}>{status}</span>
        </div>

        <p style={{ margin: "0 0 12px", color: "rgba(255,255,255,0.5)", fontSize: 12 }}>
          🎯 Palpite: <strong style={{ color: "#ddd" }}>{p.palpite || "—"}</strong>
          &nbsp;·&nbsp;{p.fotos.length} foto(s)
        </p>
        <div style={{ display: "flex", gap: 6 }}>
          <button onClick={onEdit} title="Editar"
            style={{ ...btnStyle("#2a2a4a"), fontSize: 12, padding: "6px 0", flex: 1 }}>✏️ Editar</button>
          <button onClick={onDelete} title="Remover"
            style={{ ...btnStyle("#4a1010"), fontSize: 13, padding: "6px 12px" }}>🗑️</button>
        </div>
      </div>
    </div>
  );
}

// ── Mosaico ───────────────────────────────────────────────────────────────
function PhotoMosaic({ fotos }) {
  if (!fotos.length)
    return <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 44, opacity: 0.3 }}>📷</div>;
  if (fotos.length === 1)
    return <img src={fotos[0]} alt="foto" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />;
  const cols = fotos.length <= 4 ? 2 : 3;
  const visible = fotos.slice(0, 6), extra = fotos.length - 6;
  return (
    <div style={{ display: "grid", gridTemplateColumns: `repeat(${cols}, 1fr)`, height: "100%", gap: 2 }}>
      {visible.map((src, i) => (
        <div key={i} style={{ overflow: "hidden", position: "relative" }}>
          <img src={src} alt={`foto ${i + 1}`} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
          {i === 5 && extra > 0 && (
            <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.65)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, fontWeight: "bold", color: "#fff" }}>+{extra}</div>
          )}
        </div>
      ))}
    </div>
  );
}
